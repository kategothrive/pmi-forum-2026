# D6 — Bilješke s terena

*Ono što ste čuli i zapisali kroz tri tjedna, a nije ušlo ni u jedan izvještaj*

---

**9. 3.** — Dario je usput spomenuo da Krešo "ide na drugi projekt". Krešo im je jedini
koji je radio integraciju s našim ERP-om. Nisam pitao kada. Nitko nije reagirao.

**10. 3.** — Mislav izvukao prvi set podataka iz starog sustava. Kaže da polovica kupaca
nema OIB.

**11. 3.** — Ivan, na kavi: "ako podaci iz starog sustava budu ovakvi, ovo neće proći
validaciju i onda smo gotovi s rokom."

**13. 3.** — Tomislav nije došao na sastanak drugi put zaredom. Javio je sat vremena ranije.

**13. 3.** — Prekretnica "migracija testnog seta" nije isporučena. Dario kaže "idući tjedan".

**17. 3.** — Sandra me zaustavila na hodniku: "je li servis ipak unutra ili nije? Vesna mi je
rekla da pitam tebe."

**18. 3.** — Validacija pala na 7,2 %. U registru rizika nam okidač piše 5 %.

**19. 3.** — Ana: "budžet je godišnji, ono što ne potrošimo do 30. 6. se gubi. Ako išta
prelijeće u drugo polugodište, to ide na novo odobrenje uprave."

**20. 3.** — Poslao treći upit tko potpisuje obradu osobnih podataka za migraciju. Ivan kaže
da to nije IT. Ana kaže da to nije kontroling. Pravnika nemamo, imamo vanjskog odvjetnika
kojeg nitko nije zvao.

**21. 3.** — Dvoje prodavača iz Rijeke zvali me sami i pitali hoće li morati prepisivati
svoje Excele ručno. Nitko im ništa nije rekao.

**24. 3.** — Vesna na hodniku, u prolazu: "čujem da kasnimo?" Nije stala da čuje odgovor.

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
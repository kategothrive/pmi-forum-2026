# D9 — Poruka dobavljača

*Stigla u petak u 16:50*

| | |
|---|---|
| **Od** | Dario Šimić, Lumina Systems |
| **Za** | voditelj projekta |
| **Cc** | — |
| **Datum** | 30. ožujka 2026., 16:50 |
| **Predmet** | Integracija ERP — plan resursa |

---

Pozdrav,

kao što sam obećao, javljam vezano uz plan. Situacija je nepovoljnija nego što sam mislio u
ponedjeljak: Krešimir, koji je kod nas radio vašu integraciju, od 1. 4. prelazi na drugi
projekt i nije ga moguće zadržati.

To znači da prvu verziju integracije nećemo isporučiti 10. 4. nego oko 1. 5., dakle tri
tjedna kasnije, jer kolega koji preuzima treba vrijeme da uđe u vaš ERP.

Dvije mogućnosti kako ja to vidim:

1. Idemo tim tempom i integracija je gotova početkom petog mjeseca. Nema dodatnog troška.

2. Uključujemo seniorskog konzultanta iz drugog tima, dostupan od 7. 4. Trošak je 14.000 EUR
jer je izvan ugovorenog opsega. S njim smo realno na 17. 4.

Javi mi kako želite dalje, da rezerviram ljude. Lijep pozdrav, Dario

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
# D3 — Popis zahtjeva s radionice odjela

*Sve što je izrečeno na radionici 15. siječnja, zapisano kako je rečeno*

---

| # | Zahtjev | Tko traži |
|---|---|---|
| 1 | Vidjeti sve o kupcu na jednom mjestu | Prodaja |
| 2 | Povijest kontakata s kupcem | Prodaja |
| 3 | Da se vidi tko je zadnji zvao kupca | Prodaja, Zagreb |
| 4 | Mobilna aplikacija za rad na terenu | Prodaja, Split |
| 5 | Slanje ponude izravno iz sustava | Prodaja |
| 6 | Predložak ponude po kategorijama opreme | Prodaja |
| 7 | Povezivanje s ERP-om — stanje zaliha u stvarnom vremenu | Prodaja, IT |
| 8 | Da prodavač vidi ima li nešto na skladištu | Prodaja, Rijeka |
| 9 | Prijenos postojećih kupaca iz Excela | Prodaja |
| 10 | Prijenos kontakata iz Outlooka | Svi |
| 11 | Prijenos podataka iz starog sustava u Rijeci | Rijeka |
| 12 | Čišćenje duplikata kupaca | Kontroling |
| 13 | Lijevak prilika po fazama | Prodaja |
| 14 | Izvještaj o prodaji po regijama | Uprava |
| 15 | Izvještaj o prodaji po prodavaču | Uprava |
| 16 | Da uprava vidi prognozu za kvartal | Uprava |
| 17 | Podsjetnik za follow-up nakon ponude | Prodaja |
| 18 | Da sustav sam javi kad ponuda istekne | Prodaja |
| 19 | Evidencija servisnih naloga | Servis |
| 20 | Povezivanje servisnih naloga s kupcem | Servis |
| 21 | Integracija s web shopom | Marketing |
| 22 | Slanje newslettera iz sustava | Marketing |
| 23 | Prava pristupa — da Split ne vidi Zagreb | Prodaja, Split |
| 24 | Obuka za sve korisnike | IT |
| 25 | Da radi i kad nema interneta | Prodaja, Split |
| 26 | Pohrana ugovora uz kupca | Kontroling |

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
# D1 — Brief sponzora

*E-mail kojim je projekt zapravo počeo*

| | |
|---|---|
| **Od** | Vesna Dragić, direktorica prodaje |
| **Za** | voditelj projekta |
| **Cc** | Boris Jurić (uprava) |
| **Datum** | 18. prosinca 2025., 17:42 |
| **Predmet** | CRM — krećemo u siječnju |

---

Bok,

kao što smo pričali na kolegiju, idemo konačno u CRM. Uprava je dala zeleno svjetlo i Boris
je za, tako da nam tu nema prepreka.

Ukratko što mi treba. Trenutno nitko u firmi ne zna tko je s kojim kupcem zadnji put
razgovarao. Prodaja ima svoje Excele, Rijeka ima nekakvu svoju bazu, a pola kontakata je
ljudima u Outlooku. Kad netko ode iz firme, njegovi kupci odu s njim. To moramo riješiti.

Želim da na kraju imamo pravi 360 pogled na kupca — da otvorim jednog kupca i vidim sve:
tko je, što je kupovao, gdje smo stali s ponudom, kad smo ga zadnji put zvali. I da to vide
svi, a ne samo onaj tko je vodio račun.

Budžet je nešto oko 150 do 200 tisuća, Ana zna točno. Lumina nam je već radila onu stvar s
izvještajima pa ih uzimamo i za ovo, nema smisla sad ići u javnu nabavu i gubiti dva
mjeseca.

Rok je sezona. Do 1. srpnja ljudi moraju raditi u novom sustavu, jer kad krene sezona nitko
neće imati vremena za učenje. To nam je fiksno.

Što se tiče podataka, IT će to odraditi, Ivan je rekao da je to stvar od par dana.

Nemoj da nam ispadne kao kod konkurencije — oni su uveli CRM prošle godine i ljudi ga i
dalje ne koriste.

Javi mi do kraja tjedna kako ćemo krenuti.

Vesna

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
# D2 — Bilješke s prvih razgovora

*Vaše natuknice iz prvog tjedna, onako kako ste ih zapisali*

---

**8. 1. — Ivan Perak, voditelj IT-a (45 min)**
- integracija s ERP-om je glavna stvar, ne CRM sam po sebi
- "tri mjeseca minimalno, i to ako Lumina ima nekoga tko to zna"
- Vesna misli da je migracija par dana → Ivan kaže da nije, i da joj to nitko nije rekao
- podaci na 3 mjesta: stari sustav (Rijeka), Excel po regijama, Outlook kontakti
- koliko zapisa? → "nemam pojma, nitko nije brojao"
- kvaliteta podataka: "vidjet ćemo kad izvučemo"

**8. 1. — Ana Kovačević, kontroling (20 min)**
- odobreno je 180.000, ne 200
- budžet je godišnji → ono što se ne potroši do 30. 6. ide natrag
- traži da svaki trošak ide preko nje prije narudžbe
- pita hoće li biti troška licenci i nakon projekta → nemam odgovor

**9. 1. — Sandra Milić, voditeljica servisa (30 min)**
- pitala zašto servis nije u opsegu
- servis ima 11 tehničara i vodi naloge na papiru i u Excelu
- "ako već radite sustav za kupce, mi smo s tim istim kupcima svaki dan"
- rekao sam da je to izvan opsega → nije bila zadovoljna, ali je prihvatila
- ⚠ ovo će se vratiti

**10. 1. — Tomislav Benko, regionalni voditelj Split (15 min, telefonski)**
- "imamo mi svoje Excele koji rade"
- nije htio dogovoriti termin za analizu procesa
- 9 ljudi u Splitu, to je skoro trećina prodaje
- otvoreno skeptičan, ali nije rekao ne

**12. 1. — Nikolina Horvat, marketing (20 min)**
- traži da se kasnije poveže s web shopom i newsletterom
- rekla da joj to "nije hitno, ali da imate na umu"

**Otvoreno / nitko mi nije odgovorio:**
- tko odlučuje o prioritetima kad se prodaja i IT ne slože?
- što ako Lumina kasni — imamo li uopće nešto u ugovoru o tome?
- 1. 7. je početak sezone, ali tko je rekao da je to rok projekta — Vesna ili uprava?
- obuka ljudi: tko je radi i kada? nije nigdje spomenuto
- Rijeka i Osijek — s njima nisam uopće razgovarao

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
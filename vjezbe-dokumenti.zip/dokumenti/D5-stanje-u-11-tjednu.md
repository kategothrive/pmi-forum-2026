# D5 — Stanje projekta u 11. tjednu

*Brojevi na dan 24. ožujka 2026.*

---

**Vrijeme i novac**

| Pokazatelj | Vrijednost |
|---|---|
| Proteklo vremena | 46 % (11 od 24 tjedna) |
| Dovršenost zadataka | 41 % |
| Potrošeno budžeta | 92.400 EUR od 180.000 EUR (51 %) |
| Preostalo do roka | 14 tjedana |

**Prekretnice**

| Prekretnica | Plan | Stvarno | Status |
|---|---|---|---|
| Potpisan ugovor s dobavljačem | 23. 1. | 23. 1. | na vrijeme |
| Analiza procesa prodaje završena | 13. 2. | 18. 2. | 5 dana kašnjenja |
| Testna okolina postavljena | 27. 2. | 26. 2. | na vrijeme |
| Migracija testnog seta podataka | 13. 3. | — | kasni 9 dana |
| Integracija s ERP-om — prva verzija | 10. 4. | — | u tijeku |
| Obuka korisnika | 25. 5. | — | nije započeto |
| Puštanje u rad | 22. 6. | — | nije započeto |

**Podaci**

| Pokazatelj | Vrijednost |
|---|---|
| Ukupno zapisa za migraciju (procjena) | ~31.000 |
| Migrirano u testnu okolinu | 12.400 |
| Palo na validaciji | 7,2 % |
| Pronađeno duplikata | 2.840 |

**Zadaci i rizici**

| Pokazatelj | Vrijednost |
|---|---|
| Otvorenih zadataka | 38 |
| Od toga blokiranih | 6 |
| Otvorenih rizika u registru | 9 |
| Od toga visokih | 2 |
| Korisnika prošlo obuku | 0 od 54 |

**Ocjena tima na zadnjem sastanku:** zeleno

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
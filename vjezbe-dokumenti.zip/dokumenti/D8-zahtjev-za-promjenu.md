# D8 — Zahtjev za promjenu opsega

*Mail sponzora tri dana nakon sastanka*

| | |
|---|---|
| **Od** | Vesna Dragić, direktorica prodaje |
| **Za** | voditelj projekta |
| **Cc** | Sandra Milić (servis) |
| **Datum** | 27. ožujka 2026., 21:08 |
| **Predmet** | Servis — ipak ulazi |

---

Bok,

razgovarala sam sa Sandrom i s Borisom. Slažemo se da nema smisla da servis ostane vani.
To su isti kupci, ista baza, a Sandra vodi naloge na papiru što je ionako problem za sebe.

Boris je rekao da je to logično i da mu nije jasno zašto to nije bilo od početka.

Pretpostavljam da je to mala stvar jer je ionako isti sustav — treba samo otvoriti taj dio i
pustiti servisne naloge unutra. Ne mora biti savršeno u prvoj fazi, samo da tehničari mogu
upisati nalog i da se vidi kod kupca.

Rok ostaje 1. 7., to ne diramo jer sezona ne čeka.

Možeš li to složiti s Luminom i javiti mi?

Vesna

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
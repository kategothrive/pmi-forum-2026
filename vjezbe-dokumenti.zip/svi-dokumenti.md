# Projekt Vektra CRM — svi dokumenti

**Vektra d.o.o.** — distribucija i servis profesionalne opreme za ugostiteljstvo  
165 zaposlenih, 4 lokacije (Zagreb, Split, Rijeka, Osijek)  
**Projekt:** Implementacija CRM sustava i objedinjavanje prodajnog procesa  
**Trajanje:** 12. siječnja – 30. lipnja 2026. · **Budžet:** 180.000 EUR · **Dobavljač:** Lumina Systems d.o.o.

Svi podaci su izmišljeni.

---

# D1 — Brief sponzora

*E-mail kojim je projekt zapravo počeo*

| | |
|

> **Od:** Vesna Dragić, direktorica prodaje  
> **Za:** voditelj projekta  
> **Datum:** 18. prosinca 2025., 17:42  
> **Predmet:** CRM — krećemo u siječnju

Bok,

kao što smo pričali na kolegiju, idemo konačno u CRM. Uprava je dala zeleno svjetlo i Boris
je za, tako da nam tu nema prepreka.

Ukratko što mi treba. Trenutno nitko u firmi ne zna tko je s kojim kupcem zadnji put
razgovarao. Prodaja ima svoje Excele, Rijeka ima nekakvu svoju bazu, a pola kontakata je
ljudima u Outlooku. Kad netko ode iz firme, njegovi kupci odu s njim. To moramo riješiti.

Želim da na kraju imamo pravi 360 pogled na kupca — da otvorim jednog kupca i vidim sve:
tko je, što je kupovao, gdje smo stali s ponudom, kad smo ga zadnji put zvali. I da to vide
svi, a ne samo onaj tko je vodio račun.

Budžet je nešto oko 150 do 200 tisuća, Ana zna točno. Lumina nam je već radila onu stvar s
izvještajima pa ih uzimamo i za ovo, nema smisla sad ići u javnu nabavu i gubiti dva
mjeseca.

Rok je sezona. Do 1. srpnja ljudi moraju raditi u novom sustavu, jer kad krene sezona nitko
neće imati vremena za učenje. To nam je fiksno.

Što se tiče podataka, IT će to odraditi, Ivan je rekao da je to stvar od par dana.

Nemoj da nam ispadne kao kod konkurencije — oni su uveli CRM prošle godine i ljudi ga i
dalje ne koriste.

Javi mi do kraja tjedna kako ćemo krenuti.

Vesna

---

# D2 — Bilješke s prvih razgovora

*Vaše natuknice iz prvog tjedna, onako kako ste ih zapisali*

**8. 1. — Ivan Perak, voditelj IT-a (45 min)**
- integracija s ERP-om je glavna stvar, ne CRM sam po sebi
- "tri mjeseca minimalno, i to ako Lumina ima nekoga tko to zna"
- Vesna misli da je migracija par dana → Ivan kaže da nije, i da joj to nitko nije rekao
- podaci na 3 mjesta: stari sustav (Rijeka), Excel po regijama, Outlook kontakti
- koliko zapisa? → "nemam pojma, nitko nije brojao"
- kvaliteta podataka: "vidjet ćemo kad izvučemo"

**8. 1. — Ana Kovačević, kontroling (20 min)**
- odobreno je 180.000, ne 200
- budžet je godišnji → ono što se ne potroši do 30. 6. ide natrag
- traži da svaki trošak ide preko nje prije narudžbe
- pita hoće li biti troška licenci i nakon projekta → nemam odgovor

**9. 1. — Sandra Milić, voditeljica servisa (30 min)**
- pitala zašto servis nije u opsegu
- servis ima 11 tehničara i vodi naloge na papiru i u Excelu
- "ako već radite sustav za kupce, mi smo s tim istim kupcima svaki dan"
- rekao sam da je to izvan opsega → nije bila zadovoljna, ali je prihvatila
- ⚠ ovo će se vratiti

**10. 1. — Tomislav Benko, regionalni voditelj Split (15 min, telefonski)**
- "imamo mi svoje Excele koji rade"
- nije htio dogovoriti termin za analizu procesa
- 9 ljudi u Splitu, to je skoro trećina prodaje
- otvoreno skeptičan, ali nije rekao ne

**12. 1. — Nikolina Horvat, marketing (20 min)**
- traži da se kasnije poveže s web shopom i newsletterom
- rekla da joj to "nije hitno, ali da imate na umu"

**Otvoreno / nitko mi nije odgovorio:**
- tko odlučuje o prioritetima kad se prodaja i IT ne slože?
- što ako Lumina kasni — imamo li uopće nešto u ugovoru o tome?
- 1. 7. je početak sezone, ali tko je rekao da je to rok projekta — Vesna ili uprava?
- obuka ljudi: tko je radi i kada? nije nigdje spomenuto
- Rijeka i Osijek — s njima nisam uopće razgovarao

---

# D3 — Popis zahtjeva s radionice odjela

*Sve što je izrečeno na radionici 15. siječnja, zapisano kako je rečeno*

| # | Zahtjev | Tko traži |
|---|---|---|
| 1 | Vidjeti sve o kupcu na jednom mjestu | Prodaja |
| 2 | Povijest kontakata s kupcem | Prodaja |
| 3 | Da se vidi tko je zadnji zvao kupca | Prodaja, Zagreb |
| 4 | Mobilna aplikacija za rad na terenu | Prodaja, Split |
| 5 | Slanje ponude izravno iz sustava | Prodaja |
| 6 | Predložak ponude po kategorijama opreme | Prodaja |
| 7 | Povezivanje s ERP-om — stanje zaliha u stvarnom vremenu | Prodaja, IT |
| 8 | Da prodavač vidi ima li nešto na skladištu | Prodaja, Rijeka |
| 9 | Prijenos postojećih kupaca iz Excela | Prodaja |
| 10 | Prijenos kontakata iz Outlooka | Svi |
| 11 | Prijenos podataka iz starog sustava u Rijeci | Rijeka |
| 12 | Čišćenje duplikata kupaca | Kontroling |
| 13 | Lijevak prilika po fazama | Prodaja |
| 14 | Izvještaj o prodaji po regijama | Uprava |
| 15 | Izvještaj o prodaji po prodavaču | Uprava |
| 16 | Da uprava vidi prognozu za kvartal | Uprava |
| 17 | Podsjetnik za follow-up nakon ponude | Prodaja |
| 18 | Da sustav sam javi kad ponuda istekne | Prodaja |
| 19 | Evidencija servisnih naloga | Servis |
| 20 | Povezivanje servisnih naloga s kupcem | Servis |
| 21 | Integracija s web shopom | Marketing |
| 22 | Slanje newslettera iz sustava | Marketing |
| 23 | Prava pristupa — da Split ne vidi Zagreb | Prodaja, Split |
| 24 | Obuka za sve korisnike | IT |
| 25 | Da radi i kad nema interneta | Prodaja, Split |
| 26 | Pohrana ugovora uz kupca | Kontroling |

---

# D4 — Popis sudionika projekta

*Ono što ste do sada uspjeli pobrojati*

| Ime | Pozicija | Odjel | Što ga zanima | Dostupnost |
|---|---|---|---|---|
| Vesna Dragić | direktorica prodaje | Prodaja | da ljudi stvarno koriste sustav, rok 1. 7. | teško dostupna, odgovara na mail navečer |
| Boris Jurić | član uprave | Uprava | izvještaji za upravu, trošak | jednom mjesečno, 15 min |
| Ivan Perak | voditelj IT-a | IT | integracija, sigurnost, da ne ostane njemu na vratu | dostupan, ali ima još 3 projekta |
| Ana Kovačević | kontrolerica | Financije | da se budžet potroši do 30. 6. i ni cent više | dostupna |
| Tomislav Benko | regionalni voditelj | Prodaja Split | da mu ne mijenjamo način rada | izbjegava termine |
| Sandra Milić | voditeljica servisa | Servis | da servis uđe u sustav | vrlo dostupna, zove sama |
| Nikolina Horvat | voditeljica marketinga | Marketing | web shop, newsletter | dostupna |
| Mislav Crnić | administrator baze | IT | kvaliteta podataka | dostupan preko Ivana |
| Dario Šimić | voditelj implementacije | Lumina Systems | isporuka po ugovoru | tjedni sastanak |
| ? | korisnička podrška | Podrška | ? | ? |
| 54 korisnika | prodavači i voditelji | Prodaja, sve lokacije | da im sustav ne oduzima vrijeme | — |

---

# D5 — Stanje projekta u 11. tjednu

*Brojevi na dan 24. ožujka 2026.*

**Vrijeme i novac**

| Pokazatelj | Vrijednost |
|---|---|
| Proteklo vremena | 46 % (11 od 24 tjedna) |
| Dovršenost zadataka | 41 % |
| Potrošeno budžeta | 92.400 EUR od 180.000 EUR (51 %) |
| Preostalo do roka | 14 tjedana |

**Prekretnice**

| Prekretnica | Plan | Stvarno | Status |
|---|---|---|---|
| Potpisan ugovor s dobavljačem | 23. 1. | 23. 1. | na vrijeme |
| Analiza procesa prodaje završena | 13. 2. | 18. 2. | 5 dana kašnjenja |
| Testna okolina postavljena | 27. 2. | 26. 2. | na vrijeme |
| Migracija testnog seta podataka | 13. 3. | — | kasni 9 dana |
| Integracija s ERP-om — prva verzija | 10. 4. | — | u tijeku |
| Obuka korisnika | 25. 5. | — | nije započeto |
| Puštanje u rad | 22. 6. | — | nije započeto |

**Podaci**

| Pokazatelj | Vrijednost |
|---|---|
| Ukupno zapisa za migraciju (procjena) | ~31.000 |
| Migrirano u testnu okolinu | 12.400 |
| Palo na validaciji | 7,2 % |
| Pronađeno duplikata | 2.840 |

**Zadaci i rizici**

| Pokazatelj | Vrijednost |
|---|---|
| Otvorenih zadataka | 38 |
| Od toga blokiranih | 6 |
| Otvorenih rizika u registru | 9 |
| Od toga visokih | 2 |
| Korisnika prošlo obuku | 0 od 54 |

**Ocjena tima na zadnjem sastanku:** zeleno

---

# D6 — Bilješke s terena

*Ono što ste čuli i zapisali kroz tri tjedna, a nije ušlo ni u jedan izvještaj*

**9. 3.** — Dario je usput spomenuo da Krešo "ide na drugi projekt". Krešo im je jedini
koji je radio integraciju s našim ERP-om. Nisam pitao kada. Nitko nije reagirao.

**10. 3.** — Mislav izvukao prvi set podataka iz starog sustava. Kaže da polovica kupaca
nema OIB.

**11. 3.** — Ivan, na kavi: "ako podaci iz starog sustava budu ovakvi, ovo neće proći
validaciju i onda smo gotovi s rokom."

**13. 3.** — Tomislav nije došao na sastanak drugi put zaredom. Javio je sat vremena ranije.

**13. 3.** — Prekretnica "migracija testnog seta" nije isporučena. Dario kaže "idući tjedan".

**17. 3.** — Sandra me zaustavila na hodniku: "je li servis ipak unutra ili nije? Vesna mi je
rekla da pitam tebe."

**18. 3.** — Validacija pala na 7,2 %. U registru rizika nam okidač piše 5 %.

**19. 3.** — Ana: "budžet je godišnji, ono što ne potrošimo do 30. 6. se gubi. Ako išta
prelijeće u drugo polugodište, to ide na novo odobrenje uprave."

**20. 3.** — Poslao treći upit tko potpisuje obradu osobnih podataka za migraciju. Ivan kaže
da to nije IT. Ana kaže da to nije kontroling. Pravnika nemamo, imamo vanjskog odvjetnika
kojeg nitko nije zvao.

**21. 3.** — Dvoje prodavača iz Rijeke zvali me sami i pitali hoće li morati prepisivati
svoje Excele ručno. Nitko im ništa nije rekao.

**24. 3.** — Vesna na hodniku, u prolazu: "čujem da kasnimo?" Nije stala da čuje odgovor.

---

# D7 — Transkript tjednog statusnog sastanka

*24. ožujka 2026., 9:00–9:38 · Vesna se ispričala, nije prisutna*

**PM:** Dobro, krećemo. Ivan, Dario, Sandra, Ana, Mislav, Nikolina. Vesna se
ispričala, ima kolegij. Idemo po točkama. Dario, migracija testnog seta je trebala biti gotova 13., gdje
smo?

**Dario:** Da, to je kasnilo. Imali smo problem s formatom iz starog sustava, polje za OIB
je kod njih tekstualno pa nam je parser padao. Sad to radi, pustili smo 12.400 zapisa.

**PM:** Od koliko ukupno?

**Dario:** Pa, ovisi koliko ih stvarno ima. Mislav?

**Mislav:** Oko trideset i jedan tisuću, plus-minus. Ne znam točno dok ne očistimo duplikate.

**PM:** A koliko je palo na validaciji?

**Mislav:** Sedam i nešto posto.

**Ivan:** Sedam zarez dva.

**PM:** Dobro, to je iznad onoga što smo stavili kao granicu. Imali smo pet posto u registru
rizika.

**Dario:** Je, ali to je prvi prolaz. Uvijek prvi prolaz padne više. Kad počistimo one bez
OIB-a, to će pasti.

**Ivan:** Neće samo pasti, netko to mora počistiti.

**Dario:** Pa da, to je na vašoj strani.

**Ivan:** Nije to par sati. To je dvije i pol tisuće zapisa koje netko mora ručno proći jer
nemamo iz čega izvući OIB.

**Ana:** Oprostite, a to je trošak? Jer ako je to netko vanjski, to mora proći preko mene
prije nego se naruči.

**PM:** Za sad nitko nije rekao da ide vani. Mislave, koliko bi to bilo s vaše strane?

**Mislav:** Ne znam napamet. Pogledat ću to.

**PM:** Dobro. Ivane, integracija s ERP-om, prva verzija je 10. 4.

**Ivan:** Ja čekam njih. Mi smo svoje pripremili prošli tjedan.

**Dario:** Da, mi to krećemo sad. Imamo malo gužve s resursima, ali to ćemo riješiti.

**PM:** Što znači gužva s resursima?

**Dario:** Ma ništa strašno, posložit ćemo. Javit ću ti plan do kraja tjedna.

**PM:** Dobro, do petka onda.

**Sandra:** Mogu ja nešto pitati? Ja i dalje ne znam je li servis unutra ili nije. Vesna mi
kaže da pitam tebe, ti mi kažeš da je izvan opsega, a u međuvremenu moji tehničari svaki
dan idu kod istih kupaca o kojima vi ovdje pričate.

**PM:** Sandra, u charteru piše da servis nije u opsegu ove faze.

**Sandra:** Dobro, ali to je netko napisao u siječnju. Ja pitam što je sad.

**PM:** Razumijem. To je odluka koju ne mogu donijeti ja, to ide na Vesnu i upravu.

**Sandra:** Onda ću ja pitati Vesnu.

**PM:** Dobro. Ana, budžet.

**Ana:** Potrošili smo devedeset dva tisuće. To je malo više nego što bih očekivala s obzirom
na to gdje smo. I da ponovim, ono što se ne potroši do tridesetog šestog, gubi se. Ako išta
prelijeće u drugo polugodište, to je novo odobrenje uprave, a to traje.

**PM:** Jasno. Obuka — u planu je 25. 5., nitko još nije prošao.

**Ivan:** Pa ne možemo obučavati ljude na sustavu koji nema podatke.

**PM:** Znači obuka se miče?

**Ivan:** Realno da.

**Dario:** Mi predlažemo prvi tjedan šestog.

**PM:** To je tri tjedna prije puštanja u rad.

**Ivan:** Je, ali ako idemo ranije, obučavamo ih na nečemu što se još mijenja, pa ih onda
moramo obučavati dvaput.

**PM:** Dobro, idemo s prvim tjednom šestog.

**Nikolina:** Ja sam samo htjela pitati, je li ono s web shopom negdje na popisu? Jer meni
su iz uprave pitali.

**PM:** Nije u ovoj fazi, Nikolina.

**Nikolina:** Dobro, samo da znam što da kažem.

**PM:** Još nešto? Split — Tomislav nije ni danas tu.

**Ivan:** Trebalo bi njih nekako obavijestiti što se događa, jer ljudi iz Rijeke su mene
zvali prošli tjedan.

**PM:** Dobro, to ćemo riješiti.

**Ivan:** I još nešto, onaj papir za osobne podatke. Ja to ne mogu potpisati, to nije IT.

**Ana:** Ni ja, to nije kontroling.

**PM:** Dobro, to ću podići prema Vesni. Hvala svima, vidimo se idući ponedjeljak.

---

# D8 — Zahtjev za promjenu opsega

*Mail sponzora tri dana nakon sastanka*

| | |
|

> **Od:** Vesna Dragić, direktorica prodaje  
> **Za:** voditelj projekta  
> **Datum:** 27. ožujka 2026., 21:08  
> **Predmet:** Servis — ipak ulazi

Bok,

razgovarala sam sa Sandrom i s Borisom. Slažemo se da nema smisla da servis ostane vani.
To su isti kupci, ista baza, a Sandra vodi naloge na papiru što je ionako problem za sebe.

Boris je rekao da je to logično i da mu nije jasno zašto to nije bilo od početka.

Pretpostavljam da je to mala stvar jer je ionako isti sustav — treba samo otvoriti taj dio i
pustiti servisne naloge unutra. Ne mora biti savršeno u prvoj fazi, samo da tehničari mogu
upisati nalog i da se vidi kod kupca.

Rok ostaje 1. 7., to ne diramo jer sezona ne čeka.

Možeš li to složiti s Luminom i javiti mi?

Vesna

---

# D9 — Poruka dobavljača

*Stigla u petak u 16:50*

| | |
|

> **Od:** Dario Šimić, Lumina Systems  
> **Za:** voditelj projekta  
> **Datum:** 30. ožujka 2026., 16:50  
> **Predmet:** Integracija ERP — plan resursa

Pozdrav,

kao što sam obećao, javljam vezano uz plan. Situacija je nepovoljnija nego što sam mislio u
ponedjeljak: Krešimir, koji je kod nas radio vašu integraciju, od 1. 4. prelazi na drugi
projekt i nije ga moguće zadržati.

To znači da prvu verziju integracije nećemo isporučiti 10. 4. nego oko 1. 5., dakle tri
tjedna kasnije, jer kolega koji preuzima treba vrijeme da uđe u vaš ERP.

Dvije mogućnosti kako ja to vidim:

1. Idemo tim tempom i integracija je gotova početkom petog mjeseca. Nema dodatnog troška.

2. Uključujemo seniorskog konzultanta iz drugog tima, dostupan od 7. 4. Trošak je 14.000 EUR
jer je izvan ugovorenog opsega. S njim smo realno na 17. 4.

Javi mi kako želite dalje, da rezerviram ljude. Lijep pozdrav, Dario

---

# D7 — Transkript tjednog statusnog sastanka

*24. ožujka 2026., 9:00–9:38 · Vesna se ispričala, nije prisutna*

---

**PM:** Dobro, krećemo. Ivan, Dario, Sandra, Ana, Mislav, Nikolina. Vesna se
ispričala, ima kolegij. Idemo po točkama. Dario, migracija testnog seta je trebala biti gotova 13., gdje
smo?

**Dario:** Da, to je kasnilo. Imali smo problem s formatom iz starog sustava, polje za OIB
je kod njih tekstualno pa nam je parser padao. Sad to radi, pustili smo 12.400 zapisa.

**PM:** Od koliko ukupno?

**Dario:** Pa, ovisi koliko ih stvarno ima. Mislav?

**Mislav:** Oko trideset i jedan tisuću, plus-minus. Ne znam točno dok ne očistimo duplikate.

**PM:** A koliko je palo na validaciji?

**Mislav:** Sedam i nešto posto.

**Ivan:** Sedam zarez dva.

**PM:** Dobro, to je iznad onoga što smo stavili kao granicu. Imali smo pet posto u registru
rizika.

**Dario:** Je, ali to je prvi prolaz. Uvijek prvi prolaz padne više. Kad počistimo one bez
OIB-a, to će pasti.

**Ivan:** Neće samo pasti, netko to mora počistiti.

**Dario:** Pa da, to je na vašoj strani.

**Ivan:** Nije to par sati. To je dvije i pol tisuće zapisa koje netko mora ručno proći jer
nemamo iz čega izvući OIB.

**Ana:** Oprostite, a to je trošak? Jer ako je to netko vanjski, to mora proći preko mene
prije nego se naruči.

**PM:** Za sad nitko nije rekao da ide vani. Mislave, koliko bi to bilo s vaše strane?

**Mislav:** Ne znam napamet. Pogledat ću to.

**PM:** Dobro. Ivane, integracija s ERP-om, prva verzija je 10. 4.

**Ivan:** Ja čekam njih. Mi smo svoje pripremili prošli tjedan.

**Dario:** Da, mi to krećemo sad. Imamo malo gužve s resursima, ali to ćemo riješiti.

**PM:** Što znači gužva s resursima?

**Dario:** Ma ništa strašno, posložit ćemo. Javit ću ti plan do kraja tjedna.

**PM:** Dobro, do petka onda.

**Sandra:** Mogu ja nešto pitati? Ja i dalje ne znam je li servis unutra ili nije. Vesna mi
kaže da pitam tebe, ti mi kažeš da je izvan opsega, a u međuvremenu moji tehničari svaki
dan idu kod istih kupaca o kojima vi ovdje pričate.

**PM:** Sandra, u charteru piše da servis nije u opsegu ove faze.

**Sandra:** Dobro, ali to je netko napisao u siječnju. Ja pitam što je sad.

**PM:** Razumijem. To je odluka koju ne mogu donijeti ja, to ide na Vesnu i upravu.

**Sandra:** Onda ću ja pitati Vesnu.

**PM:** Dobro. Ana, budžet.

**Ana:** Potrošili smo devedeset dva tisuće. To je malo više nego što bih očekivala s obzirom
na to gdje smo. I da ponovim, ono što se ne potroši do tridesetog šestog, gubi se. Ako išta
prelijeće u drugo polugodište, to je novo odobrenje uprave, a to traje.

**PM:** Jasno. Obuka — u planu je 25. 5., nitko još nije prošao.

**Ivan:** Pa ne možemo obučavati ljude na sustavu koji nema podatke.

**PM:** Znači obuka se miče?

**Ivan:** Realno da.

**Dario:** Mi predlažemo prvi tjedan šestog.

**PM:** To je tri tjedna prije puštanja u rad.

**Ivan:** Je, ali ako idemo ranije, obučavamo ih na nečemu što se još mijenja, pa ih onda
moramo obučavati dvaput.

**PM:** Dobro, idemo s prvim tjednom šestog.

**Nikolina:** Ja sam samo htjela pitati, je li ono s web shopom negdje na popisu? Jer meni
su iz uprave pitali.

**PM:** Nije u ovoj fazi, Nikolina.

**Nikolina:** Dobro, samo da znam što da kažem.

**PM:** Još nešto? Split — Tomislav nije ni danas tu.

**Ivan:** Trebalo bi njih nekako obavijestiti što se događa, jer ljudi iz Rijeke su mene
zvali prošli tjedan.

**PM:** Dobro, to ćemo riješiti.

**Ivan:** I još nešto, onaj papir za osobne podatke. Ja to ne mogu potpisati, to nije IT.

**Ana:** Ni ja, to nije kontroling.

**PM:** Dobro, to ću podići prema Vesni. Hvala svima, vidimo se idući ponedjeljak.

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*
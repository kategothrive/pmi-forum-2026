# D4 — Popis sudionika projekta

*Ono što ste do sada uspjeli pobrojati*

---

| Ime | Pozicija | Odjel | Što ga zanima | Dostupnost |
|---|---|---|---|---|
| Vesna Dragić | direktorica prodaje | Prodaja | da ljudi stvarno koriste sustav, rok 1. 7. | teško dostupna, odgovara na mail navečer |
| Boris Jurić | član uprave | Uprava | izvještaji za upravu, trošak | jednom mjesečno, 15 min |
| Ivan Perak | voditelj IT-a | IT | integracija, sigurnost, da ne ostane njemu na vratu | dostupan, ali ima još 3 projekta |
| Ana Kovačević | kontrolerica | Financije | da se budžet potroši do 30. 6. i ni cent više | dostupna |
| Tomislav Benko | regionalni voditelj | Prodaja Split | da mu ne mijenjamo način rada | izbjegava termine |
| Sandra Milić | voditeljica servisa | Servis | da servis uđe u sustav | vrlo dostupna, zove sama |
| Nikolina Horvat | voditeljica marketinga | Marketing | web shop, newsletter | dostupna |
| Mislav Crnić | administrator baze | IT | kvaliteta podataka | dostupan preko Ivana |
| Dario Šimić | voditelj implementacije | Lumina Systems | isporuka po ugovoru | tjedni sastanak |
| ? | korisnička podrška | Podrška | ? | ? |
| 54 korisnika | prodavači i voditelji | Prodaja, sve lokacije | da im sustav ne oduzima vrijeme | — |

---

*Fiktivni dokument. Projekt Vektra CRM — materijal za radionicu Sve AI tajne za project managere, PMI Forum 2026.*